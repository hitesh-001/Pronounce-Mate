import SwiftUI
import AVFoundation

extension Color {
    static let customPurple = Color(red: 41/255, green: 75/255, blue: 41/255)
    static let mediumPurple = Color(red: 120/255, green: 148/255, blue: 97/255)
    static let lightPurple = Color(red: 219/255, green: 231/255, blue: 201/255)
}

struct ContentView: View {
    let words = ["Cheese": "CH IY Z","ought":"AO T","hut":"HH AH T","cow":"K AW","hide":"HH AY D","hurt":"HH ER T","green":"G R IY N","eat":"IY T","key":"K IY","knee":"N IY","ping":"P IH NG","oat":"OW T","read":"R IY D","seizure":"S IY ZH ER","yield":"Y IY L D","we":"W IY","hood":"HH UH D","she":"SH IY"]
    @State private var searchText: String = ""
    @State private var labelText: String = ""
    @State private var isSearching: Bool = false
    @State private var name = "name"
    @State private var phenomic = "Phenomic"
    let synthesizer = AVSpeechSynthesizer()
    @State private var textToSpeak: String = "Choose one"
    @StateObject private var speechRecognizer = SpeechRecognizer()
    @State private var isRecording = false
    @State private var script = "speak"
    
    
    var body: some View {
        ZStack {
            Color.customPurple.edgesIgnoringSafeArea(.all)
            VStack(spacing: 10) {
                VStack(alignment: .leading){
                    Text("PronounceMate")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .fontWeight(.semibold)
                        .padding(.top, 20) 
                        // .padding(.leading,16)
                    
                    Divider()
                        .background(.gray)
                        .padding(.trailing,26)
                    
                    Text("Choose one")
                        .font(.title)
                        .foregroundColor(Color.mediumPurple)
                        .fontWeight(.semibold)
                        .padding(.top, 10) 
                        //.padding(.leading, -240)
                }.padding(.leading,26)
                
                
                ScrollView(.horizontal) {
                    HStack(spacing: 20) {
                        ForEach(words.sorted(by: <), id: \.key){ key, value in
                            Text("\(key)")
                                .padding(20)
                                .foregroundStyle(Color.customPurple)
                                .font(. system(size: 18))
                                .frame(height: 50)
                                .background(Color.lightPurple)
                                .cornerRadius(50)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 60)
                                        .stroke(Color.mediumPurple, lineWidth: 3)
                                )
                                .onTapGesture{ name = key; phenomic = value; textToSpeak = key }
                        
                        }
                    }
                }
                .scrollIndicators(.hidden)
                .padding(.leading,26)
                .padding(.trailing,26)
                
                // Rounded rectangle with button
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color(red: 219/255, green: 231/255, blue: 201/255))
                    .padding()
                    .overlay(
                        VStack(spacing: 20) {
                            Text("\(name)")
                                .foregroundColor(Color.customPurple)
                                .padding()
                                .font(.system(size: 70))
                                .fontWeight(.black)
                            Text("Tap for pronunciation")
                                .foregroundColor(Color.mediumPurple)
                                .padding()
                                .font(.caption)
                                .fontWeight(.light)
                                .padding(.top,-30)
                                .padding(.bottom,-30)
                            Text("\(phenomic)")
                                .foregroundColor(Color.mediumPurple)
                                .padding()
                                .font(.system(size: 50))
                                .fontWeight(.bold)
                            .padding(.top,-30)
                        }
                        
                    )
                    .frame(height: 300)
                    .background(Color.customPurple)
                    .padding(.bottom,-10)
                    .padding(.leading,16)
                    .padding(.trailing,16)
                    .onTapGesture(perform: {
                        speakText(textToSpeak)
                    })
                
                 // Rounded rectangle with button
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color(red: 219/255, green: 231/255, blue: 201/255))
                    .padding()
                    .overlay(
                        VStack(spacing: 20) {
                            Text("\(script)")
                                .foregroundColor(Color.mediumPurple)
                                .padding()
                                .font(.system(size: 50))
                                .fontWeight(.bold)
                        }
                    )
                    .frame(height: 300)
                    .padding(.top,-15)
                    .padding(.leading,16)
                    .padding(.trailing,16)
                    .background(Color.customPurple)
                
                Button(action: {
                    if isRecording {
                        speechRecognizer.stopTranscribing()
                        print(speechRecognizer.transcript)
                        script = speechRecognizer.transcript
                        if(script.lowercased() == name.lowercased()){
                            speakText("Well Done,You are doing good")
                        }else{
                            speakText("again")
                            script = "Again "
                        }
                        print("Recording Stop")
                    } else {
                        print("Transcribing in progress...")
                        script = "speak"
                        speechRecognizer.startTranscribing()
                    }
                    isRecording.toggle()
                }) {
                    if isRecording {
                        Image(systemName: "mic.fill")
                            .frame(width: 90, height: 90)
                            .foregroundColor(Color.customPurple)
                            .background(Color.mediumPurple)
                            .clipShape(Circle())
                        
                    }else{
                        Image(systemName: "mic.fill")
                            .frame(width: 70, height: 70)
                            .foregroundColor(Color.white)
                            .background(Color.mediumPurple)
                            .clipShape(Circle())
                    }
                    
                }
            }
            .padding(.bottom,20)
            .background(Color.customPurple)
        }
        .padding(.bottom,0)
    }
    
    func speakText(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = 0.1 // it controls the speaking rate
        synthesizer.speak(utterance)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

